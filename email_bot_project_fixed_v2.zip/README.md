# Email Bot

Simple email bot using Python.
